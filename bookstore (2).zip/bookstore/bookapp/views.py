from django.shortcuts import render,redirect
from .forms import createuserform
from django.contrib import messages
from .models import *
from django.contrib.auth import authenticate,login as dj_login,logout as dj_logout
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.contrib.auth.decorators import login_required
import json
from django.http import JsonResponse
from .forms import *
from django.db.models import Min,Max
from django.views.decorators.csrf import csrf_protect

# Create your views here.
def register(request):
    if request.user.is_authenticated:
        return redirect('home')
    else:
        form=createuserform()
        if request.method=='POST':
            form=createuserform(request.POST)
            if form.is_valid():
                form.save()
                user=form.cleaned_data.get('username')
                messages.success(request,'Account created for'+user)
                return redirect('login')
        context={'form':form}
        return render(request,'bookapp/register.html',context)

def login(request):
    if request.user.is_authenticated:

        return redirect('home')
    else:
        if request.method=='POST':
            username=request.POST.get('username')
            password=request.POST.get('password')
            users = authenticate(request, username=username, password=password)
            if users is not None:
                dj_login(request,users)
                return redirect('home')
            else:
                messages.info(request,"Username Or Password is Incorrect")
        context = {}
        return render(request, 'bookapp/login.html', context)
def logout(request):
    if request.user.is_authenticated:
        dj_logout(request)
        return redirect('login')
    else:
        return redirect('login')
def home(request):
    count=0
    if request.user.is_authenticated:
        booklists = booklistmodel.objects.get(user=request.user)
        count = booklists.getplayitems()

    context = {'count':count}

    return render(request,'bookapp/home.html',context)


def bookstore(request):
    books = bookuploads.objects.all()
    booki=bookuploads.objects.raw('select * from bookapp_bookuploads order by id desc')
    count=0
    # if request.GET.get('id'):
    #     name=request.GET.get("id")
    #     books=bookuploads.objects.raw('select * from bookapp_bookuploads where bookname like %s',[name])
    #     print("success")
    if request.user.is_authenticated:


        booklists=booklistmodel.objects.get(user=request.user)
        count = booklists.getplayitems()





    context={'books':books,'count':count,'booki':booki}
    return  render(request,'bookapp/bookstore.html',context)

def viewbook(request,id):
    count = ''
    if request.user.is_authenticated:
        booklists = booklistmodel.objects.get(user=request.user)
        count = booklists.getplayitems()
        book=bookuploads.objects.filter(pk=id)
        if request.method == 'POST':
            stars = request.POST.get('stars', '3')
            content = request.POST.get('content', '')
        # rev = bookuploads.objects.annotate(Min(revid))
            reviews = review.objects.create(book_id=id, user=request.user, stars=stars, content=content)

    # if request.method == 'POST':
    #     form = reviewform(request.POST)
    #     form.save()
    # print(book)

    book = bookuploads.objects.filter(pk=id)
    rev=review.objects.filter(book_id=id)

    context={'book':book,'count':count,'rev':rev}
    return  render(request,'bookapp/viewbook.html',context)


def bookcart(request):
        if request.user.is_authenticated:
            user = request.user
            booklists, created = booklistmodel.objects.get_or_create(user=user)
            items = booklists.bookitem_set.all()
            # count=items.count()
            count = booklists.getplayitems()
        else:
            items = []
            booklists = {'getplayitems': 0}
            count = booklists['getplayitems']
        context = {'items': items, 'booklists': booklists, 'count': count}
        return render(request,'bookapp/bookcart.html',context)
def update_item(request):
    data = json.loads(request.body)
    bookid = data['bookid']
    action = data['action']
    user = request.user
    print(bookid,action,user)
    product = bookuploads.objects.get(id=bookid)
    playlists, created = booklistmodel.objects.get_or_create(user=user,complete=False)
    bookitem.objects.get_or_create(play=playlists,bookadded=product)
    return JsonResponse("item was added",safe=False)


def deletebook(request,id):
    if request.user.is_authenticated:
        bookitem.objects.filter(bookadded_id=id).delete()
    return redirect('bookcart')