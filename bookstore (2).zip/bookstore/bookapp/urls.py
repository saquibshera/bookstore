from django.urls import path
from . import views

urlpatterns = [
    path('',views.home,name='home'),
    path('bookstore', views.bookstore, name='bookstore'),
    path('viewbook/<id>', views.viewbook, name='viewbook'),
    path('bookcart', views.bookcart, name='bookcart'),
    path('login', views.login, name='login'),
    path('register', views.register, name='register'),
    path('logout', views.logout, name='logout'),
    path('update_item', views.update_item, name='update_item'),
    path('deletebook/<id>',views.deletebook,name='deletebook')


]

