
from django.db import models
from django.contrib.auth.models import User


class bookcategory(models.Model):
    categoryname=models.CharField(max_length=200)

    def __str__(self):
        return self.categoryname


class bookuploads(models.Model):
    bookname=models.CharField(max_length=250)
    bookcategories=models.ForeignKey(bookcategory,on_delete=models.SET_NULL,blank=True,null=True)
    bookdescription=models.TextField(max_length=2000)
    bookimage=models.ImageField(upload_to='images',blank=True)
    bookurl=models.FileField(upload_to='bookpdf',blank=True)


    def __str__(self):
        return self.bookname

    @property
    def imageURL(self):
        try:
            return self.bookimage.url
        except:
            url = ''
            return url

    @property
    def bookurls(self):
        try:
            return self.bookurl.url
        except:
            url=''
        return url

class booklistmodel(models.Model):
        user = models.ForeignKey(User, on_delete=models.SET_NULL, blank=True, null=True)
        complete = models.BooleanField(default=False, null=True, blank=False)
        datetimeadded = models.DateTimeField(auto_now_add=True)

        def __str__(self):
            return str(self.id)

        def getplayitems(self):
            items = self.bookitem_set.all()
            total = items.count()
            return total


class bookitem(models.Model):
    bookadded = models.ForeignKey(bookuploads, on_delete=models.SET_NULL, blank=True, null=True)
    play = models.ForeignKey(booklistmodel, on_delete=models.SET_NULL, blank=True, null=True)
    dateadded = models.DateTimeField(auto_now_add=True)

class review(models.Model):
    user = models.ForeignKey(User, related_name='reviews', on_delete=models.SET_NULL, blank=True, null=True)
    book = models.ForeignKey(bookuploads, related_name='reviews', on_delete=models.SET_NULL, blank=True, null=True)
    content=models.TextField(blank=True,null=True)
    stars=models.IntegerField()
    dateadded = models.DateTimeField(auto_now_add=True)