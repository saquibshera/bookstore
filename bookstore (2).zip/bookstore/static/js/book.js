$(document).ready(function()
{
    console.log("hello")
    $(".add-playlist").click(function()
{
         var bookid=this.dataset.book
       var action=this.dataset.action
     console.log('bookid:',bookid,'action',action)

     if(user==="Anonymoususer")
     {
        Console.log("anonymous logged in")
     }
     else
     {
       updateUserOrder(bookid,action)
            console.log("hello")
     }
})
        function updateUserOrder(bookid,action)
        {

                console.log("sending data")
                console.log(bookid)

                var url='/update_item'

                fetch(url,{
                method:'POST',
                headers:{
                    'Content-Type':'application-json',
                    'X-CSRFToken':csrftoken,
                },
                body:JSON.stringify({'bookid':bookid,'action':action})

                })
                .then((response) =>{
                return response.json()
                })
                .then((data) =>{
                location.reload()
                        console.log('data',data)


                })
         }
	$("#input").on("keyup",function()
							{
								var value=$(this).val().toLowerCase();
								$("#tbodyy tr").filter(function()
								{
									$(this).toggle($(this).text().toLowerCase().indexOf(value)>-1)
								});
							});
})
